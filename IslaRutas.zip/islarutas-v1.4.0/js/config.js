/* IslaRutas · Configuración pública del frontend.
 * Los valores de este archivo son visibles para cualquier visitante.
 * No se deben guardar aquí contraseñas, claves privadas ni datos sensibles.
 */
window.ISLARUTAS_CONFIG = Object.freeze({
  nombreAplicacion: "IslaRutas",
  entorno: "preproduccion",
  nivelLog: "DEBUG", // ERROR | WARN | INFO | DEBUG
  responsable: "SIN_ASIGNAR",
  version: "1.4.0",
  urlCatalogo: "./preproduccion/datos/experiencias.json",
  maxEventosVisibles: 14
});
