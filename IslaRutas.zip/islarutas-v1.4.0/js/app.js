/* IslaRutas v1.4.0 · Aplicación demostrativa del catálogo.
 * Dependencias: ./js/config.js y ./datos/experiencias.json.
 * El catálogo funciona en Apache; abrir index.html mediante file:// no equivale a desplegarlo.
 */
(() => {
  "use strict";
  const byId = id => document.getElementById(id);
  const severidades = Object.freeze({ ERROR: 0, WARN: 1, INFO: 2, DEBUG: 3 });
  const configuracion = window.ISLARUTAS_CONFIG;
  const listaLogs = byId("listaLogs");
  const estado = byId("estadoDespliegue");
  const catalogo = byId("catalogo");
  let actividades = [];
  let catalogoCargado = false;
  let totalEventos = 0;

  function escribirTexto(id, valor) { const el = byId(id); if (el) el.textContent = String(valor); }
  function registrar(nivel, codigo, mensaje) {
    if (!configuracion) return;
    const nivelActual = String(configuracion.nivelLog || "ERROR").toUpperCase();
    const umbral = severidades[nivelActual] ?? severidades.ERROR;
    if (severidades[nivel] === undefined || severidades[nivel] > umbral) return;
    if (totalEventos === 0) listaLogs.replaceChildren();
    const li = document.createElement("li");
    li.className = `log-line log-${nivel.toLowerCase()}`;
    const etiqueta = document.createElement("span"); etiqueta.className = "log-level"; etiqueta.textContent = nivel;
    const descripcion = document.createElement("p");
    const hora = new Date().toLocaleTimeString("es-ES", {hour:"2-digit", minute:"2-digit", second:"2-digit"});
    descripcion.textContent = `${hora} · ${codigo} · ${mensaje}`;
    li.append(etiqueta, descripcion); listaLogs.prepend(li);
    totalEventos++;
    const maximo = Math.max(4, Number(configuracion.maxEventosVisibles) || 14);
    while (listaLogs.children.length > maximo) listaLogs.lastElementChild.remove();
    escribirTexto("contadorLogs", `${totalEventos} eventos visibles de nivel ${nivelActual} o superior`);
    const metodo = nivel === "ERROR" ? "error" : nivel === "WARN" ? "warn" : "info";
    console[metodo](`[IslaRutas][${nivel}][${codigo}] ${mensaje}`);
  }

  function mostrarEstado() {
    const envOk = configuracion.entorno === "produccion";
    const nombreOk = typeof configuracion.responsable === "string" && configuracion.responsable.trim().length > 4 && configuracion.responsable !== "SIN_ASIGNAR";
    const codigoOk = typeof configuracion.codigoVerificacion === "string" && configuracion.codigoVerificacion.trim().length >= 5 && configuracion.codigoVerificacion !== "PENDIENTE";
    const nivelOk = Object.hasOwn(severidades, String(configuracion.nivelLog).toUpperCase());
    const validado = envOk && nombreOk && codigoOk && nivelOk && catalogoCargado;
    estado.className = `deploy-status ${validado ? "deploy-success" : "deploy-pending"}`;
    estado.textContent = validado ? "● CONFIGURACIÓN APLICADA" : "● PENDIENTE DE VALIDACIÓN";
    escribirTexto("catalogoEstado", catalogoCargado ? "Recibido por HTTP" : "Sin cargar / incidencia");
  }

  if (!configuracion) {
    estado.textContent = "ERROR: No se ha cargado js/config.js";
    estado.className = "deploy-status deploy-pending";
    catalogo.textContent = "No se puede iniciar la web: falta su fichero de configuración.";
    return;
  }
  escribirTexto("entornoValor", configuracion.entorno || "Sin configurar");
  escribirTexto("nivelLogValor", configuracion.nivelLog || "Sin configurar");
  escribirTexto("responsableValor", configuracion.responsable || "Sin asignar");
  escribirTexto("codigoValor", configuracion.codigoVerificacion || "PENDIENTE");
  escribirTexto("versionValor", configuracion.version || "—");
  mostrarEstado();
  registrar("INFO", "APP-100", `Inicializando versión ${configuracion.version} en ${configuracion.entorno}`);
  if (configuracion.entorno !== "produccion") registrar("WARN", "CFG-201", "La aplicación todavía no está configurada para producción");
  if (configuracion.codigoVerificacion === "PENDIENTE") registrar("WARN", "CFG-202", "Falta la clave individual de verificación");
  registrar("DEBUG", "CFG-099", `URL del catálogo configurada: ${configuracion.urlCatalogo}`);

  function numero(valor) { return Number(valor).toLocaleString("es-ES"); }
  function precio(valor) { return new Intl.NumberFormat("es-ES", {style:"currency", currency:"EUR", maximumFractionDigits:0}).format(Number(valor)); }
  function normalizar(valor) { return String(valor || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase(); }
  function elemento(tag, clase, texto) { const el = document.createElement(tag); if (clase) el.className = clase; if (texto !== undefined) el.textContent = texto; return el; }
  const ilustracionesCategoria = Object.freeze({ "Senderismo":"senderismo", "Cultura":"cultura", "Mar":"mar", "Naturaleza":"naturaleza", "Gastronomía":"gastronomia" });

  function agregarOpciones(id, valores) {
    const select = byId(id);
    for (const valor of [...new Set(valores)].sort((a,b)=>a.localeCompare(b,"es"))) {
      const opt = document.createElement("option"); opt.value = valor; opt.textContent = valor; select.append(opt);
    }
  }

  function crearTarjeta(item) {
    const article = elemento("article", "experience-card");
    const portada = elemento("div", "experience-cover");
    const img = document.createElement("img");
    const tema = ilustracionesCategoria[item.categoria] || "naturaleza";
    img.src = `./assets/${tema}.svg`; img.alt = `Ilustración de la experiencia ${item.nombre}`; img.loading = "eager";
    img.width = 640; img.height = 390;
    portada.append(img);
    if (item.destacada) portada.append(elemento("span", "feature-tag", "✦ Destacada"));
    portada.append(elemento("span", "island-tag", item.isla));
    const body = elemento("div", "experience-body");
    body.append(elemento("span", "experience-category", item.categoria));
    body.append(elemento("h3", "experience-title", item.nombre));
    body.append(elemento("p", "experience-description", item.descripcion));
    const meta = elemento("div", "experience-meta");
    meta.append(elemento("span", "meta-location", `⌖ ${item.municipio}`));
    meta.append(elemento("span", "meta-duration", `◷ ${item.duracionHoras} h`));
    const bottom = elemento("div", "experience-bottom");
    const precioBloque = elemento("div", "price-block");
    precioBloque.append(elemento("small", "", "Desde"), elemento("strong", "", precio(item.precioDesde)));
    bottom.append(precioBloque, elemento("span", "difficulty-tag", item.dificultad));
    body.append(meta, bottom); article.append(portada, body);
    return article;
  }

  function renderizar() {
    const isla = byId("filtroIsla").value;
    const categoria = byId("filtroCategoria").value;
    const buscado = normalizar(byId("buscar").value.trim());
    const filtradas = actividades.filter(item =>
      (isla === "todas" || item.isla === isla) &&
      (categoria === "todas" || item.categoria === categoria) &&
      (!buscado || normalizar(`${item.nombre} ${item.descripcion} ${item.municipio} ${item.isla} ${item.categoria}`).includes(buscado))
    );
    catalogo.replaceChildren();
    if (filtradas.length === 0) {
      const vacio = elemento("div", "empty-results");
      vacio.append(elemento("strong", "", "No hemos encontrado experiencias con esos filtros."));
      vacio.append(elemento("p", "", "Prueba otra isla, categoría o búsqueda."));
      catalogo.append(vacio);
      registrar("WARN", "UI-310", `Sin coincidencias: isla=${isla}, categoría=${categoria}`);
    } else {
      for (const item of filtradas) catalogo.append(crearTarjeta(item));
    }
    escribirTexto("contador", `${filtradas.length} de ${actividades.length} experiencias`);
    registrar("DEBUG", "UI-311", `Filtros aplicados: ${filtradas.length} resultados (isla=${isla}, categoría=${categoria})`);
  }

  async function cargarCatalogo() {
    registrar("INFO", "API-101", "Solicitando el catálogo al servidor web");
    try {
      const respuesta = await fetch(configuracion.urlCatalogo, {cache:"no-store"});
      if (!respuesta.ok) throw new Error(`HTTP ${respuesta.status} al solicitar ${configuracion.urlCatalogo}`);
      const json = await respuesta.json();
      if (!Array.isArray(json.experiencias)) throw new Error("Formato JSON incorrecto: falta la lista experiencias");
      if (json.experiencias.some(e => !e.id || !e.nombre || !e.isla || !e.categoria)) throw new Error("El catálogo contiene registros incompletos");
      actividades = json.experiencias;
      catalogoCargado = true;
      for (const campo of ["filtroIsla", "filtroCategoria"]) {
        byId(campo).replaceChildren();
        const primera = document.createElement("option"); primera.value = "todas"; primera.textContent = campo === "filtroIsla" ? "Todas las islas" : "Todas las categorías";
        byId(campo).append(primera);
      }
      agregarOpciones("filtroIsla", actividades.map(e => e.isla));
      agregarOpciones("filtroCategoria", actividades.map(e => e.categoria));
      escribirTexto("totalExperiencias", numero(actividades.length));
      escribirTexto("totalIslas", numero(new Set(actividades.map(e => e.isla)).size));
      registrar("INFO", "API-200", `Catálogo recibido correctamente: ${actividades.length} experiencias`);
      registrar("DEBUG", "API-201", `Origen de los datos: ${configuracion.urlCatalogo}`);
      mostrarEstado(); renderizar();
    } catch (error) {
      catalogoCargado = false;
      catalogo.replaceChildren();
      const errorPanel = elemento("div", "error-message");
      errorPanel.append(elemento("strong", "", "No se puede cargar el catálogo"));
      errorPanel.append(elemento("p", "", "Comprueba en la terminal que existe el recurso JSON y que su URL es correcta."));
      catalogo.append(errorPanel);
      registrar("ERROR", "API-404", error.message);
      escribirTexto("contador", "Catálogo no disponible");
      mostrarEstado();
    }
  }
  byId("filtroIsla").addEventListener("change", renderizar);
  byId("filtroCategoria").addEventListener("change", renderizar);
  byId("buscar").addEventListener("input", renderizar);
  byId("limpiarFiltros").addEventListener("click", () => { byId("filtroIsla").value="todas"; byId("filtroCategoria").value="todas"; byId("buscar").value=""; renderizar(); });
  byId("recargarCatalogo").addEventListener("click", cargarCatalogo);
  cargarCatalogo();
})();
