# ORDEN DE TRABAJO — ATLÁNTICO DIGITAL · AD-DEP-042
**Proyecto:** IslaRutas · Versión 1.4.0 · **Fecha:** 12/11/2026 · **Prioridad:** Alta
**Cliente:** IslaRutas Canarias (ficticio) · **Equipo:** Sistemas / Desarrollo Web

## Solicitud del cliente
Publicar la versión de demostración del portal de experiencias en el servidor Ubuntu de pruebas, accesible en `http://127.0.0.1/islarutas/`.
El portal es frontend estático: **HTML + CSS + JavaScript + JSON + imágenes SVG**. No requiere base de datos, Node.js ni servidor de aplicaciones.

## Condiciones de aceptación
1. Las hojas de estilo y los scripts cargan correctamente desde su ubicación definitiva.
2. El catálogo JSON se solicita correctamente por HTTP y muestra **12 experiencias de 8 islas**.
3. Funcionan los filtros de isla, categoría y la búsqueda de texto.
4. En `js/config.js`: `entorno = "produccion"`, `nivelLog = "INFO"`, `responsable = "nombre y primer apellido"`, `urlCatalogo = "./datos/experiencias.json"`.
5. El panel técnico de la web mostrará los valores actuales del fichero de configuración. Con INFO no deben aparecer mensajes DEBUG en el registro visual. No se necesita ningún código individual.
6. La publicación contendrá **solo** `index.html`, `css/`, `js/`, `datos/` y `assets/`.
7. No serán accesibles mediante el navegador `docs/`, `config/`, `registros/`, ni `.revision-interna`.
8. Se preparará una copia `tar.gz` que se pueda recuperar y comparar.

## Advertencias
- No modificar `js/app.js` ni el fichero `datos/experiencias.json`: los errores de entrega que debe corregir el técnico afectan a **rutas y parámetros de configuración**, no al código de negocio.
- `config/entorno-interno.conf` es información de práctica reservada: proteger con permisos de propietario y **no publicarla**.
- Los archivos de `registros/` son **históricos**, procedentes del ensayo de preproducción. No son registros de Apache de la publicación actual.
- No guardar contraseñas reales en `js/config.js`: un fichero servido al navegador es público.
