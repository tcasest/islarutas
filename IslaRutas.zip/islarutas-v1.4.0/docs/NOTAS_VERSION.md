# IslaRutas v1.4.0 — Cambios previstos

- Catálogo aumentado a 12 experiencias de las 8 islas.
- Búsqueda de texto y filtrado combinado por isla y categoría.
- Monitor de despliegue con valores de configuración y eventos por nivel.
- Nuevo diseño responsive y recursos SVG locales, sin dependencias externas.
- Entrega de preproducción pendiente de revisión de rutas y variables del entorno.
