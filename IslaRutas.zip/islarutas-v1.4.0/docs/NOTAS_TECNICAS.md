# Notas técnicas — arquitectura IslaRutas

## Componentes
- `index.html`: estructura y controles del catálogo; enlaza estilos y scripts.
- `css/estilos.css`: maquetación responsive y estilos de la web.
- `js/config.js`: parámetros **públicos** del frontend. Se carga antes que `js/app.js`.
- `js/app.js`: inicia la interfaz y obtiene el catálogo con la API Fetch del navegador.
- `datos/experiencias.json`: listado estático de 12 experiencias de demostración.
- `assets/*.svg`: ilustraciones locales; no requieren acceso a Internet.

## Secuencia HTTP esperada
El navegador solicita `/islarutas/`, después recursos CSS y JS; `app.js` ejecuta `fetch(config.urlCatalogo)` y solicita `/islarutas/datos/experiencias.json`. Si cualquiera de esas rutas es errónea, puede producirse un 404. Una página HTML con respuesta 200 no garantiza por sí sola que funcione toda la aplicación.

## Niveles de registro del frontend
`ERROR` = solo errores; `WARN` = errores y avisos; `INFO` = añade eventos operativos; `DEBUG` = incluye los detalles técnicos más verbosos. Son eventos del navegador, no mensajes de `journalctl`.

## Herramientas de diagnóstico
Comprobar archivos con `find`, `grep`, `tree`, `cat` y `ls`; comparar recursos con `diff`; revisar Apache con `systemctl`, procesos con `ps` y puerto con `ss`; verificar las URLs usando `curl -I`.
